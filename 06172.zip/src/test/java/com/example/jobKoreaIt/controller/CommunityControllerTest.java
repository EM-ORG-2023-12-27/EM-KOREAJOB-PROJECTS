package com.example.jobKoreaIt.controller;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CommunityControllerTest {

    @Test
    void list() {
    }
}