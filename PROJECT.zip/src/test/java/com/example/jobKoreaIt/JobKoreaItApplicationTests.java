package com.example.jobKoreaIt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobKoreaItApplicationTests {

	@Test
	void contextLoads() {
	}

}
