package com.example.jobKoreaIt.controller;


import com.example.jobKoreaIt.domain.common.dto.CommunityDto;
import com.example.jobKoreaIt.domain.common.service.CommunityServiceImpl;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.io.IOException;

@Controller
@Slf4j
@RequestMapping("/community")
public class CommunityController {

    @Autowired
    private CommunityServiceImpl communityService;

    @GetMapping("/index")
    public void index(){
        log.info("GET /community/index...");
    }

    @GetMapping("/add")
    public void add(){
        log.info("GET /community/add.css...");
    }


    @PostMapping("/add") // @ModelAttribute 는 DTO를 받아 그럼 해당 클래스 객체를 찾아서 필드값과 HTML에 있는 NAME값들과 매핑해서 세팅해주는 역할
    public String add_post(@ModelAttribute  @Valid CommunityDto dto, BindingResult bindingResult, Model model) throws IOException {
        log.info("GET /community/add..." + dto); // @Valid 어노테이션을 사용하면 CommunityDto 객체의 필드 값들이 유효한지 확인해줌.
        //유효성 검사 >> 여기서 Dto 값이 제대로 들어오는지를 확인하는 곳 만약 콘솔로그에 Dto 값이 들어오는 것을 확인하려면
        //System.out.println("dto = " + dto + ", bindingResult = " + bindingResult + ", model = " + model); 이렇게 해당 값들이 들어오는 것을 확인해줄 수 있음.
        if(bindingResult.hasFieldErrors()) {
            for(FieldError error  : bindingResult.getFieldErrors()) {
                log.info(error.getField()+ " : " + error.getDefaultMessage());
                model.addAttribute(error.getField(), error.getDefaultMessage()); //이와 같은 경우는 모델을 이용해서 에러 메세지를 뷰단으로 보내줘서 클라이언트에게 DTO를 전달하는게됨.
            }
            return "community/add"; // if ~ return 구문은 거의 정형화된 유효성 검사 코드 dto 값이 들어오는 것에 대해서 확인하고,
                                    // 잘못되는 경우에 모델객체 메서드를 이용해서 에러 사항을 뷰단에 보내주는 역할을 해준다.
        }
        //서비스 실행 >> 만약 유효성 검사를 성공하고 넘겻을 때 실행되는 코드로, isadded 라는 변수에 dto 값이 들어오는 서비스단(여기선 add 메서드)가 잘 작동되면,
        // 리스트로, 아니면, 다시 add 페이지로 넘어가는 로직
        boolean isadded = communityService.addCommunity(dto);
        if(!isadded)
            return "community/add"; // 리턴값으로 반환할때는 정확하게 다 url을 전달해야하는지 + redirect 경우는 왜 저렇게 해야하는건지. 그냥 community/list

        return "redirect:/community/list"; // 여기선 DTO 값이 클라이언트에게 넘어가는 것이 아닌 그냥 정적 페이지를 보여주는 역할만을 수행함.

    }

    @GetMapping("/list")
    public void list(){
        log.info("GET /community/list...");
    }

    @GetMapping("/read")
    public void read(){
        log.info("GET /community/read...");
    }

    @GetMapping("/update")
    public void update(){
        log.info("GET /community/update...");
    }

}
