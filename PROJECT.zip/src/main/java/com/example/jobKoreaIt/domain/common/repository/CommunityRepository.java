package com.example.jobKoreaIt.domain.common.repository;


import com.example.jobKoreaIt.domain.common.entity.Community;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository // Repository는 service 와 DB 를 연결해주는 역할.
public interface CommunityRepository extends JpaRepository<Community,Long> { // Community = 엔티티 / Long PK 키의 타입
}
