package com.example.jobKoreaIt.domain.common.dto;


import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CommunityDto {
    private Long no; // 페이지 넘버를 가르킴
    @NotBlank(message = "username을 입력하세요") // 유효성검사 어노테이션으로, 값이 입력이 안됫을 경우 빈칸에 "" 문자열 값을 출력하는 역할을 함.
    @Email(message = "올바른 이메일 주소를 입력하세요") // 이 역시 유효성검사 어노테이션.
    private String username;
    private String title;
    private String content;
    private String category;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime regdate;
    private Long count;

    private MultipartFile[] files;
}
