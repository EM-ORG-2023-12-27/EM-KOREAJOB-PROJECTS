package com.example.demo;


import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.UUID;

@Controller
@Slf4j
public class UpdownloadController {
    String UPLOAD_PATH="c:\\upload";

    @GetMapping("/upload")
    public void upload(){

    }
    //단일파일 업로드
    @PostMapping("/upload")
    public void up_file_post(@RequestParam("singleFile") MultipartFile file) throws IllegalStateException, IOException {
        log.info("POST /upload/file.."+file);


        //개별폴더 생성(UUID)
        String subDir = UPLOAD_PATH + File.separator + UUID.randomUUID();
        File dir = new File(subDir);
        if(!dir.exists())
            dir.mkdirs();//폴더 생성


        log.info("FILENAME : " + file.getOriginalFilename());
        log.info("FILESIZE : " + file.getSize() + " byte");

        //파일명 추출
        String filename = file.getOriginalFilename();
        //파일객체 생성
        File fileObject = new File(subDir,filename);
        //업로드
        file.transferTo(fileObject);

    }

    @GetMapping(value="/download",produces= MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public @ResponseBody ResponseEntity<Resource> downloadFile() throws UnsupportedEncodingException {
        log.info("GET /download..");
        String filepath = null;
        filepath=UPLOAD_PATH + File.separator+"39a41415-5790-45d4-b765-d6a8abb545e5"+File.separator+"IT_대구 강사석.jpg";
        //FileSystemResource : 파일시스템의 특정 파일로부터 정보를 가져오는데 사용
        Resource resource = new FileSystemResource(filepath);
        //파일명 추출
        String filename = resource.getFilename();
        //헤더 정보 추가
        HttpHeaders headers = new HttpHeaders();
        //ISO-8859-1 : 라틴어(특수문자등 깨짐 방지)
        headers.add("Content-Disposition","attachment; filename="+new String(filename.getBytes("UTF-8"),"ISO-8859-1"));
        //리소스,파일정보가 포함된 헤더,상태정보를 전달
        return new ResponseEntity<Resource>(resource,headers, HttpStatus.OK);
    }


}
