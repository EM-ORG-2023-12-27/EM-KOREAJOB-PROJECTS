package com.example.jobKoreaIt.domain.common.service;

// DTO >> Entity (Entity Class)
// Entity >> DTO (DTO Class)

import com.example.jobKoreaIt.domain.common.dto.CommunityDto;
import com.example.jobKoreaIt.domain.common.dto.Criteria;
import com.example.jobKoreaIt.domain.common.dto.PageDto;
import com.example.jobKoreaIt.domain.common.entity.Community;
import com.example.jobKoreaIt.domain.common.repository.CommunityRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Service
@Slf4j
@RequiredArgsConstructor
public class CommunityServiceImpl implements CommunityService{

    @Autowired
    private CommunityRepository communityRepository;

    @Transactional(rollbackFor = Exception.class)
    public boolean addCommunity(CommunityDto dto) throws IOException {

        Community community = new Community();
        community.setTitle(dto.getTitle());
        community.setContent(dto.getContent());
        community.setUsername(dto.getUsername());
        community.setCount(0L);
        community.setRegdate(LocalDateTime.now());
        community.setCategory(dto.getCategory());

        // 파일 첨부 부분은(보류)

        community = communityRepository.save(community);

        boolean issaved = communityRepository.existsById(community.getNo());

        return issaved;
    }

    @Transactional(rollbackFor = Exception.class)
    public Map<String, Object> GetCommunityList(Criteria criteria){
        Map<String, Object> returns = new HashMap();

        int totalcount = (int) communityRepository.count();
        System.out.println("COUNT = " + totalcount);

        PageDto pageDto = new PageDto(totalcount,criteria);

        int offest = (criteria.getPageno()-1) * criteria.getAmount();

        List<Community> list =null;

        list = communityRepository.findCommunityAmountStart(pageDto.getCriteria().getAmount(),offest);

        List<Community> list2 = communityRepository.findAll();

        returns.put("list",list);
        returns.put("pageDto",pageDto);
        returns.put("total",totalcount);
        returns.put("list2",list2);


        return returns; // 자바에서는 메소드가 한번에 하나의 값만 반환 할 수 있기 때문에
        // 여러개의 값을 반환해야하는 경우에 Map<String, Object> 을 이용함
    }

    // 조회에 쓰이는 서비스단.
    @Transactional(rollbackFor = Exception.class)
    public Community getCommunity(Long no){
        return communityRepository.findById(no).get();
    }

}
