package com.example.jobKoreaIt.controller;


import com.example.jobKoreaIt.domain.common.dto.CommunityDto;
import com.example.jobKoreaIt.domain.common.dto.Criteria;
import com.example.jobKoreaIt.domain.common.dto.PageDto;
import com.example.jobKoreaIt.domain.common.entity.Community;
import com.example.jobKoreaIt.domain.common.service.CommunityServiceImpl;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.query.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Controller
@Slf4j
@RequestMapping("/community")
public class CommunityController {

    @Autowired
    private CommunityServiceImpl communityService;

    @GetMapping("/index")
    public void index() {
        log.info("GET /community/index...");
    }

    @GetMapping("/add")
    public void add() {
        log.info("GET /community/add.css...");
    }


    @PostMapping("/add")
    public String add_post(@ModelAttribute @Valid CommunityDto dto, BindingResult bindingResult, Model model) throws IOException {
        log.info("GET /community/add.css...");
        System.out.println("communityDto = " + dto + ", bindingResult = " + bindingResult + ", model = " + model);

        //유효성 검사
        if (bindingResult.hasFieldErrors()) {
            for (FieldError error : bindingResult.getFieldErrors()) {
                log.info(error.getField() + " : " + error.getDefaultMessage());
                model.addAttribute(error.getField(), error.getDefaultMessage());
            }
            return "community/add";
        }
        boolean isadded = communityService.addCommunity(dto);
        if(!isadded)
            return "community/add";

        return "redirect:/community/list";
    }

    @GetMapping("/list") // 리스트로 들어오면, 실행되는 컨트롤러
    // @RequestParam 어노테이션은 정수형인 pageNo 와 "pageNo" 이라고 요청받는 문자열을 매핑 시키며, required = false 에 의해서 요청이없더라도 오류가 발생하지않음.
    public String list(@RequestParam(value = "pageNo", required = false)Integer pageNo, Model model) throws Exception{
        log.info("GET /community/list...");

        Criteria criteria = null; // criteria 의 값을 null로 초기화 해주며,
        if (pageNo==null){ // 항등 연산자에 대한 개념을 알아 둘 것, 해당 pageNo 가 null 이었을때,
            pageNo = 1; // pageNo 는 1로 초기화 해주고,
            criteria = new Criteria(); //Criteria 메서드를 실행시킨다.

        } else {
            criteria = new Criteria(pageNo,10); //만약 널값이었을 경우에는
        }

        Map<String, Object> map = communityService.GetCommunityList(criteria);

        PageDto pageDto = (PageDto) map.get("pageDto");
        int total = (int)map.get("total");

        List<Community> list = (List<Community>) map.get("list");
        List<Community> list2 = (List<Community>) map.get("list2"); // 리스트에 나오는 데이터 정보 근데 왜 list2

        //View 전달
        model.addAttribute("list",list);
        model.addAttribute("total",total);
        model.addAttribute("pageNo",pageNo);
        model.addAttribute("pageDto",pageDto);
        model.addAttribute("list2",list2);

        return "community/list";
    }

    @GetMapping("/read")
    public void read(@RequestParam("no") Long no, @RequestParam("pageNo") Long pageNo, Model model){
        log.info("GET /community/read...no : " + no + " pageNo :" + pageNo);
        Community community = communityService.getCommunity(no);

        model.addAttribute("community",community);

    }

    @GetMapping("/update")
    public void update(){
        log.info("GET /community/update...");
    }

    @GetMapping("/delete")
    public void delete(){
        log.info("Get /community/delete...");
    }

}
