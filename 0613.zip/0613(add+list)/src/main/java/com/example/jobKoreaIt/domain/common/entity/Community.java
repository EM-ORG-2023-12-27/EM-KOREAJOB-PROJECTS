package com.example.jobKoreaIt.domain.common.entity;


import com.example.jobKoreaIt.domain.common.dto.CommunityDto;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
public class Community {
    @Id // pk 컬럼 지정. 반드시 필수.
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Mysql 기준으로 Auto_increment
    private Long no;
    private String username;
    private String title;
    private String content;
    private String category;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime regdate;
    private Long count;
    private String dirpath;
    private String filename;
    private String filesize;


}
