-- TEST ACCOUNT
insert ignore into user(username,password,role) values('user1','$2a$10$fFHaNo7/UMh7rtp3LAjH0e2ZcoI2a7Ju.TUdWt.Nc52iWN1OkALkC','ROLE_USER')
insert ignore into user(username,password,role) values('seeker1','$2a$10$fFHaNo7/UMh7rtp3LAjH0e2ZcoI2a7Ju.TUdWt.Nc52iWN1OkALkC','ROLE_SEEKER')
insert ignore into user(username,password,role) values('offer1','$2a$10$fFHaNo7/UMh7rtp3LAjH0e2ZcoI2a7Ju.TUdWt.Nc52iWN1OkALkC','ROLE_OFFER')
insert ignore into user(username,password,role) values('admin','$2a$10$fFHaNo7/UMh7rtp3LAjH0e2ZcoI2a7Ju.TUdWt.Nc52iWN1OkALkC','ROLE_ADMIN')

